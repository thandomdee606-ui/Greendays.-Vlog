-- The Kasi Chronicles: initial Supabase schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  bio text,
  created_at timestamptz not null default now(),
  constraint username_format check (username is null or username ~ '^[a-zA-Z0-9_]{3,24}$')
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 5 and 140),
  body text not null check (char_length(body) between 20 and 20000),
  category text not null default 'Kasi life'
    check (category in ('Kasi life','Real talk','Safe choices','The hustle','Relationships','Wellbeing')),
  visibility text not null default 'public' check (visibility in ('public','members')),
  status text not null default 'published' check (status in ('draft','published','hidden')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 2 and 3000),
  status text not null default 'published' check (status in ('published','hidden')),
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references public.profiles(id) on delete set null,
  post_id uuid references public.posts(id) on delete cascade,
  comment_id uuid references public.comments(id) on delete cascade,
  reason text not null check (char_length(reason) between 5 and 1000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now(),
  constraint report_target check (post_id is not null or comment_id is not null)
);

create table if not exists public.support_payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  provider text not null default 'payfast',
  provider_payment_id text unique,
  payment_type text not null check (payment_type in ('once_off','monthly')),
  amount_zar numeric(10,2) not null check (amount_zar > 0),
  status text not null default 'pending' check (status in ('pending','paid','failed','cancelled')),
  created_at timestamptz not null default now()
);

-- Create a profile automatically when a user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    nullif(new.raw_user_meta_data ->> 'username', ''),
    nullif(new.raw_user_meta_data ->> 'display_name', '')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.reports enable row level security;
alter table public.support_payments enable row level security;

-- Profiles: public read; users update only their own profile.
create policy "Profiles are viewable" on public.profiles for select using (true);
create policy "Users insert own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "Users update own profile" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- Public posts are readable by everyone. Members-only posts are served through the API.
create policy "Published public posts are readable" on public.posts
for select using (status = 'published' and visibility = 'public');
create policy "Authenticated users create posts" on public.posts
for insert to authenticated with check (auth.uid() = author_id);
create policy "Authors update own posts" on public.posts
for update to authenticated using (auth.uid() = author_id) with check (auth.uid() = author_id);
create policy "Authors delete own posts" on public.posts
for delete to authenticated using (auth.uid() = author_id);

create policy "Published comments are readable" on public.comments
for select using (status = 'published');
create policy "Authenticated users comment" on public.comments
for insert to authenticated with check (auth.uid() = author_id);
create policy "Authors hide own comments" on public.comments
for update to authenticated using (auth.uid() = author_id) with check (auth.uid() = author_id);

-- Users can submit reports, but cannot read or alter the moderation queue.
create policy "Authenticated users submit reports" on public.reports
for insert to authenticated with check (auth.uid() = reporter_id);
create policy "Users view own support payments" on public.support_payments
for select to authenticated using (auth.uid() = user_id);

-- No client-side insert/update policy for support_payments. The server creates pending
-- records and verified provider notifications will update them using the service role.
