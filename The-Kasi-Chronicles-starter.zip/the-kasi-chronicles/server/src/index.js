import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createClient } from '@supabase/supabase-js';

const app = express();
const port = Number(process.env.PORT || 4000);
const supabaseUrl = process.env.SUPABASE_URL;
const anonKey = process.env.SUPABASE_ANON_KEY;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const admin = supabaseUrl && serviceKey ? createClient(supabaseUrl, serviceKey) : null;

app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '30kb' }));

function requireConfig(_req, res, next) {
  if (!admin || !anonKey) return res.status(503).json({ error: 'Server is not configured. Add Supabase environment variables.' });
  next();
}

async function requireUser(req, res, next) {
  try {
    const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
    if (!token) return res.status(401).json({ error: 'Sign in is required.' });
    const authClient = createClient(supabaseUrl, anonKey, { auth: { persistSession: false } });
    const { data, error } = await authClient.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: 'Your session is invalid or expired. Please sign in again.' });
    req.user = data.user;
    next();
  } catch {
    return res.status(401).json({ error: 'Could not verify your session.' });
  }
}

app.get('/api/health', (_req, res) => res.json({ ok: true, name: 'The Kasi Chronicles API' }));

app.get('/api/posts', requireConfig, async (req, res) => {
  const category = req.query.category;
  let query = admin.from('posts')
    .select('id,title,body,category,visibility,created_at,profiles(display_name,username)')
    .eq('status', 'published').eq('visibility', 'public')
    .order('created_at', { ascending: false }).limit(50);
  if (typeof category === 'string' && category.length < 40 && category !== 'All') query = query.eq('category', category);
  const { data, error } = await query;
  if (error) return res.status(500).json({ error: 'Unable to load stories.' });
  res.json({ posts: data || [] });
});

app.post('/api/posts', requireConfig, requireUser, async (req, res) => {
  const { title, body, category = 'Kasi life' } = req.body || {};
  const allowed = ['Kasi life','Real talk','Safe choices','The hustle','Relationships','Wellbeing'];
  if (typeof title !== 'string' || title.trim().length < 5 || title.trim().length > 140)
    return res.status(400).json({ error: 'Title must be between 5 and 140 characters.' });
  if (typeof body !== 'string' || body.trim().length < 20 || body.trim().length > 20000)
    return res.status(400).json({ error: 'Story must be between 20 and 20,000 characters.' });
  if (!allowed.includes(category)) return res.status(400).json({ error: 'Choose a valid category.' });
  const { data, error } = await admin.from('posts').insert({
    author_id: req.user.id, title: title.trim(), body: body.trim(), category, visibility: 'public', status: 'published'
  }).select('id,title,body,category,created_at').single();
  if (error) return res.status(500).json({ error: 'Could not publish story. Make sure your profile was created.' });
  res.status(201).json({ post: data });
});

app.get('/api/posts/:id/comments', requireConfig, async (req, res) => {
  const { data, error } = await admin.from('comments')
    .select('id,body,created_at,profiles(display_name,username)')
    .eq('post_id', req.params.id).eq('status', 'published').order('created_at');
  if (error) return res.status(500).json({ error: 'Unable to load comments.' });
  res.json({ comments: data || [] });
});

app.post('/api/posts/:id/comments', requireConfig, requireUser, async (req, res) => {
  const body = req.body?.body;
  if (typeof body !== 'string' || body.trim().length < 2 || body.trim().length > 3000)
    return res.status(400).json({ error: 'Comment must be between 2 and 3,000 characters.' });
  const { data, error } = await admin.from('comments').insert({
    post_id: req.params.id, author_id: req.user.id, body: body.trim()
  }).select('id,body,created_at').single();
  if (error) return res.status(400).json({ error: 'Could not add comment. Check that the story exists.' });
  res.status(201).json({ comment: data });
});

app.post('/api/reports', requireConfig, requireUser, async (req, res) => {
  const { post_id = null, comment_id = null, reason } = req.body || {};
  if ((!post_id && !comment_id) || typeof reason !== 'string' || reason.trim().length < 5 || reason.trim().length > 1000)
    return res.status(400).json({ error: 'Choose a post or comment and provide a reason (5–1,000 characters).' });
  const { error } = await admin.from('reports').insert({
    reporter_id: req.user.id, post_id, comment_id, reason: reason.trim()
  });
  if (error) return res.status(500).json({ error: 'Could not submit report.' });
  res.status(201).json({ message: 'Report submitted for moderator review.' });
});

app.post('/api/payments/checkout', requireConfig, requireUser, async (req, res) => {
  const { amount, type } = req.body || {};
  if (!Number.isFinite(amount) || amount < 10 || amount > 5000 || !['monthly', 'once_off'].includes(type))
    return res.status(400).json({ error: 'Choose a valid support amount and payment type.' });

  // Intentionally fail closed until the PayFast checkout and ITN verification
  // implementation is configured. Never unlock membership from a browser redirect.
  const required = ['PAYFAST_MERCHANT_ID', 'PAYFAST_MERCHANT_KEY', 'PAYFAST_NOTIFY_URL'];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length) return res.status(503).json({
    error: 'Secure payments are not activated yet. The site owner must configure PayFast and verified payment notifications.'
  });

  // Pending payment record; provider checkout generation is the next integration step.
  const { data: payment, error } = await admin.from('support_payments').insert({
    user_id: req.user.id, payment_type: type, amount_zar: amount, status: 'pending'
  }).select('id').single();
  if (error) return res.status(500).json({ error: 'Could not start support checkout.' });

  return res.status(501).json({
    error: 'PayFast credentials are present, but checkout generation and ITN signature/source verification must be completed before accepting payments.',
    reference: payment.id
  });
});

app.post('/api/payments/payfast/notify', (_req, res) => {
  // Do not mark a payment paid here until PayFast ITN signature, source, merchant,
  // amount and pending-reference checks are implemented and tested.
  res.status(501).send('Payment notification verification is not configured.');
});

app.listen(port, () => console.log(`The Kasi Chronicles API listening on http://localhost:${port}`));
