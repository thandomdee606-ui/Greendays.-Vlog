# The Kasi Chronicles

A full-stack starter for a Daveyton-rooted blog and community platform.

## What's included

- React + Vite responsive frontend
- Supabase email/password authentication
- PostgreSQL schema for profiles, posts, comments, reports and support payments
- Express API with Supabase JWT verification
- Public story feed and signed-in post creation
- Community comments and report endpoint
- Membership/support page with monthly and once-off support options
- PayFast checkout hand-off scaffold (credentials and public ITN URL required)

**Payments are not live by default.** Never collect card details yourself. Real payment activation requires your PayFast merchant account, public HTTPS deployment, verified ITN notifications and testing in sandbox mode.

## 1. Requirements

- Node.js 20+
- npm
- A Supabase project
- Optional: PayFast merchant account for payments

## 2. Configure Supabase

1. Create a project at https://supabase.com.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Authentication > Providers, enable Email.
4. Copy the project URL, anon key and service-role key from Project Settings > API.
5. Copy `.env.example` to `.env` in the project root and fill in the Supabase values.

Keep `SUPABASE_SERVICE_ROLE_KEY` on the server only. Never put it in `client/.env`.

## 3. Install and run

```bash
npm install
npm run dev
```

Frontend: http://localhost:5173  
API health check: http://localhost:4000/api/health

## 4. PayFast setup

The starter creates a PayFast payment hand-off URL, but payment processing is deliberately disabled until you configure the merchant details and a public HTTPS notification endpoint.

1. Create/configure a PayFast merchant account.
2. Set the PayFast environment variables in `.env`.
3. Deploy the API over HTTPS and set `PAYFAST_NOTIFY_URL` to `/api/payments/payfast/notify`.
4. Complete PayFast's required ITN validation (including signature validation, source/IP validation, amount and merchant checks) against the current PayFast documentation before accepting a payment as paid.
5. Keep supporter access locked until a verified ITN is received and reconciled to a server-created pending payment.
6. Test monthly subscriptions and once-off payments in sandbox before switching to production.

The included notification route intentionally does **not** mark payments successful. It returns a safe placeholder until full provider verification is implemented.

## 5. Before public launch

- Add email verification, password reset and rate limiting.
- Add moderation tools and a clear community code of conduct.
- Review POPIA obligations, privacy notice, retention and deletion process.
- Add age policy and safety escalation/contact guidance.
- Implement verified PayFast ITN handling and subscription cancellation/renewal state.
- Add admin roles, post editing/deletion, spam controls and backups.
- Replace demo copy and contact details with your real details.

## Project structure

```text
client/                 React application
server/                 Express API
supabase/schema.sql     Database schema and RLS policies
```
