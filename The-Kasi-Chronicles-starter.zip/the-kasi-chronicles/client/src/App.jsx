import { useEffect, useState } from 'react';
import { Link, NavLink, Route, Routes, useNavigate } from 'react-router-dom';
import { apiUrl, supabase } from './supabase';

const categories = ['All', 'Kasi life', 'Real talk', 'Safe choices', 'The hustle', 'Relationships', 'Wellbeing'];

function Header({ session }) {
  return <header className="site-header"><div className="container nav">
    <Link className="brand" to="/">THE KASI<span> CHRONICLES.</span></Link>
    <nav><NavLink to="/">Stories</NavLink><a href="/#community">Community</a><NavLink to="/support">Support</NavLink></nav>
    <div className="nav-user">{session ? <span className="signed-in">{session.user.email}</span> : <Link className="btn btn-small" to="/account">Sign in</Link>}</div>
  </div></header>;
}

function Home({ session }) {
  const [posts, setPosts] = useState([]);
  const [category, setCategory] = useState('All');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [postCategory, setPostCategory] = useState('Kasi life');
  const [message, setMessage] = useState('');

  async function loadPosts() {
    setLoading(true); setError('');
    try {
      const res = await fetch(`${apiUrl}/api/posts`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not load stories');
      setPosts(data.posts || []);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }
  useEffect(() => { loadPosts(); }, []);

  async function publish(e) {
    e.preventDefault(); setMessage('');
    if (!supabase || !session) return setMessage('Please sign in first.');
    const { data: { session: current } } = await supabase.auth.getSession();
    const res = await fetch(`${apiUrl}/api/posts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${current.access_token}` },
      body: JSON.stringify({ title, body, category: postCategory })
    });
    const data = await res.json();
    if (!res.ok) return setMessage(data.error || 'Could not publish your story.');
    setTitle(''); setBody(''); setMessage('Your story has been published. Thank you for adding your voice.');
    loadPosts();
  }

  const visible = category === 'All' ? posts : posts.filter(p => p.category === category);
  return <>
    <section className="hero"><div className="container hero-grid">
      <div><p className="eyebrow">DAVEYTON ROOTS · COMMUNITY VOICES</p>
        <h1>OUR STORIES.<br/><em>OUR STREETS.</em><br/>OUR FUTURE.</h1>
        <p className="hero-copy">A home for honest Kasi stories, everyday conversations and lessons that help us make safer choices. Speak openly. Respect each other. Build beyond the block.</p>
        <div className="actions"><a className="btn" href="#stories">Read the stories ↗</a><Link className="btn btn-outline" to="/support">Support the platform</Link></div>
      </div>
      <div className="hero-panel"><div className="hero-panel-top">THE KASI CHRONICLES / VOL. 01</div><div className="hero-panel-main"><span>REAL LIFE</span><strong>NO ONE<br/>HAS TO<br/>FIGURE IT<br/><i>OUT ALONE.</i></strong></div><div className="hero-panel-bottom">CULTURE · CONVERSATION · GROWTH</div></div>
    </div></section>
    <div className="ticker">READ HONESTLY　·　SPEAK RESPECTFULLY　·　LOOK OUT FOR ONE ANOTHER</div>
    <section className="section" id="stories"><div className="container">
      <div className="section-title"><div><p className="eyebrow">THE COMMUNITY JOURNAL</p><h2>Latest stories<span>.</span></h2></div><p>Experiences, ideas and lessons from people living the everyday reality.</p></div>
      <div className="filters">{categories.map(c => <button key={c} className={category === c ? 'filter active' : 'filter'} onClick={() => setCategory(c)}>{c}</button>)}</div>
      {loading ? <p className="muted">Loading stories…</p> : error ? <p className="notice">{error}. Check your Supabase and API setup.</p> : visible.length === 0 ? <div className="empty"><h3>No stories here yet.</h3><p>Be one of the first to share a thoughtful story with the community.</p></div> :
        <div className="story-grid">{visible.map(p => <article className="story-card" key={p.id}><p className="eyebrow">{p.category} · {new Date(p.created_at).toLocaleDateString()}</p><h3>{p.title}</h3><p>{p.body.slice(0, 190)}{p.body.length > 190 ? '…' : ''}</p><small>By {p.profiles?.display_name || p.profiles?.username || 'Kasi community member'}</small></article>)}</div>}
    </div></section>
    <section className="section dark-section" id="community"><div className="container community-grid"><div><p className="eyebrow">A SPACE TO TALK</p><h2>Different lives.<br/><em>Shared lessons.</em></h2></div><div><p>Talk about relationships, pressure, work, identity, safety and the things that rarely make it into the group chat. Keep it respectful. Protect people's privacy. No threats, harassment or exposing someone else's personal story.</p><a className="text-link" href="#write">Add your voice ↗</a></div></div></section>
    <section className="section" id="write"><div className="container write-grid"><div><p className="eyebrow">PUBLISH A STORY</p><h2>Your voice<br/>belongs here<span>.</span></h2><p className="muted">Share an experience, an opinion or a lesson. Don't include private details about other people without their permission.</p></div>
      <form className="form-card" onSubmit={publish}><h3>Write for the Chronicles</h3>
        {!session && <p className="notice">Sign in to publish a story. <Link to="/account">Create an account →</Link></p>}
        <label>Story title<input required minLength="5" maxLength="140" value={title} onChange={e => setTitle(e.target.value)} placeholder="Give your story a title"/></label>
        <label>Category<select value={postCategory} onChange={e => setPostCategory(e.target.value)}>{categories.slice(1).map(c => <option key={c}>{c}</option>)}</select></label>
        <label>Your story<textarea required minLength="20" maxLength="20000" rows="6" value={body} onChange={e => setBody(e.target.value)} placeholder="What's on your mind?"></textarea></label>
        <button className="btn" type="submit">Publish story ↗</button>{message && <p className="notice">{message}</p>}
      </form>
    </div></section>
  </>;
}

function Account({ onSession }) {
  const [mode, setMode] = useState('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setMessage('');
    if (!supabase) return setMessage('Supabase is not configured. Add the VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY values.');
    setBusy(true);
    try {
      const result = mode === 'signup'
        ? await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName } } })
        : await supabase.auth.signInWithPassword({ email, password });
      if (result.error) throw result.error;
      if (result.data.session) { onSession(result.data.session); setMessage('You are signed in.'); }
      else setMessage('Check your email for the confirmation link, then sign in.');
    } catch (e) { setMessage(e.message); }
    finally { setBusy(false); }
  }
  return <section className="section"><div className="container account-wrap"><form className="form-card" onSubmit={submit}>
    <p className="eyebrow">JOIN THE COMMUNITY</p><h2>{mode === 'signup' ? 'Create your account.' : 'Welcome back.'}</h2>
    {mode === 'signup' && <label>Display name<input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="How should we call you?"/></label>}
    <label>Email address<input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"/></label>
    <label>Password<input type="password" required minLength="8" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters"/></label>
    <button className="btn" disabled={busy}>{busy ? 'Please wait…' : mode === 'signup' ? 'Create account' : 'Sign in'}</button>
    <p className="notice">{message}</p>
    <button type="button" className="text-button" onClick={() => setMode(mode === 'signup' ? 'signin' : 'signup')}>{mode === 'signup' ? 'Already a member? Sign in' : 'New here? Create an account'}</button>
  </form></div></section>;
}

function Support() {
  const [amount, setAmount] = useState('29');
  const [kind, setKind] = useState('monthly');
  const [message, setMessage] = useState('');
  async function checkout() {
    if (!supabase) return setMessage('Set up Supabase first before taking payments.');
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return setMessage('Please create an account or sign in before supporting.');
    try {
      const res = await fetch(`${apiUrl}/api/payments/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ amount: Number(amount), type: kind })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Checkout is not available yet.');
      window.location.href = data.checkoutUrl;
    } catch (e) { setMessage(e.message); }
  }
  return <section className="section"><div className="container support-wrap"><div><p className="eyebrow">BACK THE VOICES</p><h1 className="support-heading">Keep the<br/><em>stories going.</em></h1><p className="hero-copy">Support independent community storytelling. Public safety information and essential resources will remain free to everyone.</p></div>
    <div className="form-card"><h2>Choose your support</h2><div className="choice-row"><button className={kind === 'monthly' ? 'choice selected' : 'choice'} onClick={() => setKind('monthly')}>Monthly</button><button className={kind === 'once_off' ? 'choice selected' : 'choice'} onClick={() => setKind('once_off')}>Once-off</button></div>
      <label>Amount (ZAR)<select value={amount} onChange={e => setAmount(e.target.value)}><option value="29">R29</option><option value="59">R59</option><option value="99">R99</option><option value="150">R150</option><option value="250">R250</option></select></label>
      <button className="btn" onClick={checkout}>Continue to secure support ↗</button>
      <p className="notice">Payment checkout is a setup placeholder until PayFast merchant credentials and verified payment notifications are configured.</p>{message && <p className="notice">{message}</p>}
    </div></div></section>;
}

export default function App() {
  const [session, setSession] = useState(null);
  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => subscription.unsubscribe();
  }, []);
  return <><Header session={session}/><Routes>
    <Route path="/" element={<Home session={session}/>}/>
    <Route path="/account" element={<Account onSession={setSession}/>}/>
    <Route path="/support" element={<Support/>}/>
    <Route path="*" element={<section className="section container"><h2>Page not found.</h2><Link className="text-link" to="/">Back home</Link></section>}/>
  </Routes><footer><div className="container footer"><Link className="brand" to="/">THE KASI<span> CHRONICLES.</span></Link><p>Real stories. Honest conversations. Safer choices.</p><small>© {new Date().getFullYear()} The Kasi Chronicles · Built for community.</small></div></footer></>;
}